/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercicio_1;

/**
 *
 * @author alunolab02
 */
public class Exercicio_1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
